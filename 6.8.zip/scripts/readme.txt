USAGE - remove the "prefix" so the final name matches the file in the root app folder!
Copy into main folder and replace the original one. Maybe make a backup if you want to swap!

EXAMPLE:
POE2_ELEMENTAL_INVOCATION__THREAD_CUSTOM.AHK -> THREAD_CUSTOM_1.AHK or THREAD_CUSTOM_2.AHK -> depending on the UI checkbox

some scripts toggle with a key: usually "y" . they start off!