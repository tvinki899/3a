# HighlightedItems

Please remove folder PoEHelper\Plugins\Compiled\HighlightedItems if you use it before

Copy plugin to PoEHelper\Plugins\Source\HighlightedItems