USAGE - remove the "prefix" so the final name matches the file in the root app folder!
Copy into main folder and replace the original one. Maybe make a backup if you want to swap!

EXAMPLE:
ELEMENTAL_INVOCATION__THREAD_CUSTOM -> __THREAD_CUSTOM